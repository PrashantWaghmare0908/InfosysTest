package com.example.infosysdemo.presenter;


import com.example.infosysdemo.interfaces.ApiCallContract;
import com.example.infosysdemo.model.DataModel;
import com.example.infosysdemo.repository.ApiCallRepository;
import com.example.infosysdemo.repository.ApiCallRepositoryCallback;

public class ApiCallPresenter implements ApiCallContract.ApiCallPresenter {

    ApiCallContract.ApiCallView apiCallView;

    public ApiCallPresenter(ApiCallContract.ApiCallView apiCallView) {
        this.apiCallView = apiCallView;
    }

    @Override
    public void hitApiCall() {
        ApiCallRepository.hitApi(new ApiCallRepositoryCallback() {
            @Override
            public void onResponseSuccess(DataModel response) {
                apiCallView.successResponse(response);
            }

            @Override
            public void onError(String failedMessage) {
                apiCallView.failResponse("Api called failed with : "+failedMessage);
            }
        });

    }
}
