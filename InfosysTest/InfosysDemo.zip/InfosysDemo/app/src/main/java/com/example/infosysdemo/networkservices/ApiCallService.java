package com.example.infosysdemo.networkservices;
import com.example.infosysdemo.model.DataModel;


import retrofit2.Call;
import retrofit2.http.GET;
public interface ApiCallService {
    @GET("facts.json")
    Call<DataModel> initCall();
}
