package com.example.infosysdemo.interfaces;

import com.example.infosysdemo.model.DataModel;


public interface ApiCallContract {
    interface ApiCallPresenter{
         void hitApiCall();
    }

    interface ApiCallView{
        void successResponse(DataModel response);
        void failResponse(String failMessage);
    }
}
