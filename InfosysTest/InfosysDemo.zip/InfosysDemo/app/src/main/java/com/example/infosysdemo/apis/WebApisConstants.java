package com.example.infosysdemo.apis;

public class WebApisConstants {
    public static final String WEB_SERVICE_API =  "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json";
}
