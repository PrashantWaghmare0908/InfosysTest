package com.example.infosysdemo.repository;


import com.example.infosysdemo.model.DataModel;


public interface ApiCallRepositoryCallback {
    public void onResponseSuccess(DataModel response);
    public void onError(String msg);
}
